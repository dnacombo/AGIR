if IsOSX
    return
else

if ~libisloaded('inpout32')
    p = [fileparts(which(mfilename)) '\Inpout\Win32'];
    addpath(p);
    loadlibrary('inpout32', [p '\inpout32.h'])
end
end