if libisloaded('inpout32')
    unloadlibrary('inpout32')
end