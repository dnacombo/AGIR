function SendTrigger(triggervalue, triggerduration);
% function SendTrigger(triggervalue, triggerduration);
%
% triggervalue: numerical value of trigger code to be sent (1-255).
% triggerduration: duration of the trigger signal in seconds (eg. 0.020).
%
% Requires access to function 'outlpt1' - put it in your MATLAB path.

if IsOSX
    return
else
    try
        calllib('inpout32', 'Out32', 888, triggervalue);
    catch
        disp('Warning! Could not send trigger! Did you OpenTriggerPort?')
    end
    WaitSecs(triggerduration);
    try
        calllib('inpout32', 'Out32', 888, 0);
    end
end